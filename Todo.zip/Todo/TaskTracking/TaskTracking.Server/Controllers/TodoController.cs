﻿using Microsoft.AspNetCore.Mvc;
using TaskTracking.Server;
using TaskTracking.Server.Controllers;
using TaskTracking.Server.Repositories;

[ApiController]
[Route("[controller]")]
public class TodoController : ControllerBase
{
    //private static List<TodoItem> Todos = new List<TodoItem>
    //   {
    //       new TodoItem { Id = 1, Name = "Task 1", Completed = false },
    //       new TodoItem { Id = 2, Name = "Task 2", Completed = true }
    //   };
    private readonly ILogger<TodoController> _logger;
    private readonly ITodoRepository _todoRepository;

    public TodoController(ILogger<TodoController> logger, ITodoRepository todoRepository)
    { 
        _logger = logger;
        _todoRepository = todoRepository;
    }

    [HttpGet(Name = "GetTodo")]
    public ActionResult<IEnumerable<TodoItem>> Get()
    {
        var todos = _todoRepository.GetTodos();
        return Ok(todos);
    }

    [HttpPut("{id}")]
    public ActionResult<IEnumerable<TodoItem>>  UpdateTodoStatus(int id)
    {
        var isUpdated = _todoRepository.UpdateTodo(id);
        if (!isUpdated)
        {
            var td = _todoRepository.GetTodos();
            return NotFound();
        }

        var todos = _todoRepository.GetTodos();
        return Ok(todos);
        
    }
}