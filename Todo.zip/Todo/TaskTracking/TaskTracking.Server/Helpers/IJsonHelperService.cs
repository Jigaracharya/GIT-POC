﻿namespace TaskTracking.Server.Helpers
{
    public interface IJsonHelperService
    {
        List<TodoItem> ReadTodosFromFile();
        void WriteTodoToFile(List<TodoItem> todos);
    }
}
