﻿using System.Text.Json;

namespace TaskTracking.Server.Helpers
{
    public class JsonHelperService : IJsonHelperService
    {
        private readonly string JsonFilePath = "Database\\todos.json";       

        public List<TodoItem> ReadTodosFromFile()
        {
            if (!System.IO.File.Exists(JsonFilePath))
            {
                return new List<TodoItem>();
            }

            var json = System.IO.File.ReadAllText(JsonFilePath);
            return JsonSerializer.Deserialize<List<TodoItem>>(json) ?? new List<TodoItem>();
        }

        public void WriteTodoToFile(List<TodoItem> todos)
        {
            var json = JsonSerializer.Serialize(todos);
            System.IO.File.WriteAllText(JsonFilePath, json);
        }
    }
}
