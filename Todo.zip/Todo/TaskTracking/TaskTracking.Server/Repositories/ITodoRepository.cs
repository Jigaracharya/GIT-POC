﻿namespace TaskTracking.Server.Repositories
{
    public interface ITodoRepository
    {
        List<TodoItem> GetTodos();
        bool UpdateTodo(int id);
    }
}
