﻿using TaskTracking.Server.Helpers;

namespace TaskTracking.Server.Repositories.Impl
{
    public class ToDoRepository : ITodoRepository
    {
        private readonly IJsonHelperService _jsonHelperService;
        public ToDoRepository(IJsonHelperService jsonHelperService)
        {
            _jsonHelperService = jsonHelperService;
        }

        public List<TodoItem> GetTodos()
        {
            var todos = _jsonHelperService.ReadTodosFromFile();
            return todos;
        }

        public bool UpdateTodo(int id)
        {
            var todos = _jsonHelperService.ReadTodosFromFile();
            var todo = todos.FirstOrDefault(t => t.Id == id);
            if(todo != null)
            {
                todo.Completed = !todo.Completed;
                _jsonHelperService.WriteTodoToFile(todos);
                return true;
            }          
            return false;
        }
    }
}