﻿using Microsoft.AspNetCore.Mvc;
using Moq;
using TaskTracking.Server.Repositories;
using Microsoft.Extensions.Logging;

namespace TaskTracking.Server.Test.Controllers
{
    [TestClass]
    public class TodoControllerTests
    {
        private Mock<ILogger<TodoController>> _mockLogger;
        private Mock<ITodoRepository> _mockTodoRepository;
        private TodoController _controller;

        [TestInitialize]
        public void Setup()
        {
            _mockLogger = new Mock<ILogger<TodoController>>();
            _mockTodoRepository = new Mock<ITodoRepository>();
            _controller = new TodoController(_mockLogger.Object, _mockTodoRepository.Object);

        }

        [TestMethod]
        public void Get_ReturnsOkResult_WithListOfTodos()
        {
            // Arrange
            var todos = new List<TodoItem>
            {
                new TodoItem { Id = 1, Name = "Task 1", Completed = false },
                new TodoItem { Id = 2, Name = "Task 2", Completed = true }
            };
            _mockTodoRepository.Setup(repo => repo.GetTodos()).Returns(todos);

            // Act
            var result = _controller.Get();

            // Assert
            Assert.IsInstanceOfType(result.Result, typeof(OkObjectResult));

            var okResult = result.Result as OkObjectResult;
            var returnValue = okResult?.Value;
            Assert.IsInstanceOfType(returnValue, typeof(List<TodoItem>));
            Assert.AreEqual(2, ((List<TodoItem>)returnValue).Count);
        }

        [TestMethod]
        public void UpdateTodoStatus_ReturnsOkResult_WithUpdatedTodos()
        {
            // Arrange
            var todos = new List<TodoItem>
            {
                new TodoItem { Id = 1, Name = "Task 1", Completed = false },
                new TodoItem { Id = 2, Name = "Task 2", Completed = true }
            };
            _mockTodoRepository.Setup(repo => repo.GetTodos()).Returns(todos);
            _mockTodoRepository.Setup(repo => repo.UpdateTodo(It.IsAny<int>())).Returns(true);

            // Act
            var result = _controller.UpdateTodoStatus(1);

            // Assert
            Assert.IsInstanceOfType(result.Result, typeof(OkObjectResult));
            var okResult = result.Result as OkObjectResult;
            var returnValue = okResult?.Value;
            Assert.IsInstanceOfType(returnValue, typeof(List<TodoItem>));
            Assert.AreEqual(2, ((List<TodoItem>)returnValue).Count);
        }

        [TestMethod]
        public void UpdateTodoStatus_ReturnsNotFound_WhenTodoNotFound()
        {
            // Arrange
            _mockTodoRepository.Setup(repo => repo.UpdateTodo(It.IsAny<int>())).Returns(false);

            // Act
            var result = _controller.UpdateTodoStatus(1);

            // Assert
            Assert.IsInstanceOfType(result.Result, typeof(NotFoundResult));
        }
    }
}
