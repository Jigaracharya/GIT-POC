import React from 'react';
import TodoItem from './TodoItem';

interface Todo {
    id: number;
    name: string;
    completed: boolean;
}

interface TodoListProps {
    todos: Todo[];
    toggleTodoStatus: (id: number) => void;
}

const TodoList: React.FC<TodoListProps> = ({ todos, toggleTodoStatus }) => {
    return (
        <ul>
            {todos.map(todo => (
                <TodoItem key={todo.id} todo={todo} toggleTodoStatus={toggleTodoStatus} />
            ))}
        </ul>
    );
};

export default TodoList;
