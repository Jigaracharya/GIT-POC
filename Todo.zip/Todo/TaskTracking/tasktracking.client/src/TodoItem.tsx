import React from 'react';

interface Todo {
    id: number;
    name: string;
    completed: boolean;
}

interface TodoItemProps {
    todo: Todo;
    toggleTodoStatus: (id: number) => void;
}

const TodoItem: React.FC<TodoItemProps> = ({ todo, toggleTodoStatus }) => {
    return (
        <li>
            <span style={{ textDecoration: todo.completed ? 'line-through' : 'none' }}>
                {todo.name}
            </span>
            <button onClick={() => toggleTodoStatus(todo.id)}>
                {todo.completed ? 'Mark as Pending' : 'Mark as Completed'}
            </button>
        </li>
    );
};

export default TodoItem;
