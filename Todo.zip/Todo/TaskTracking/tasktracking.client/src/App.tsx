import React, { useState, useEffect } from 'react';
import TodoList from './TodoList';
import Filter from './Filter';
import './App.css';

interface Todo {
    id: number;
    name: string;
    completed: boolean;
}

const App: React.FC = () => {
    const [todos, setTodos] = useState<Todo[]>([]);
    const [filter, setFilter] = useState<string>('all');

    useEffect(() => {
        
        // Fetch to-do items from the backend
        fetch('/todo')
            .then(response => response.json())
            .then(data => setTodos(data));
    }, []);

    const toggleTodoStatus = (id: number) => {
        fetch(`/todo/${id}`, { method: 'PUT' })
            .then(response => response.json())
            .then(data => setTodos(data));
    };

    const filteredTodos = todos.filter(todo =>
        filter === 'all' ? true : filter === 'completed' ? todo.completed : !todo.completed
    );

    return (
        <div className="app">
            <h1>To-Do List</h1>
            <Filter setFilter={setFilter} />
            <TodoList todos={filteredTodos} toggleTodoStatus={toggleTodoStatus} />
        </div>
    );
};

export default App;